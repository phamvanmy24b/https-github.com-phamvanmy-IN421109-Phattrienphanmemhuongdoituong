﻿using EduHub.Application.Services;
using EduHub.Domain.Entities;
using EduHub.Domain.Repositories;
using Microsoft.AspNetCore.Mvc;
using System;

namespace EduHub.API.Controllers;

[ApiController]
[Route("api")]
public class EventsController : ControllerBase
{
    private readonly EventService _eventService;
    private readonly IEventRepository _eventRepository;

    public EventsController(EventService eventService, IEventRepository eventRepository)
    {
        _eventService = eventService;
        _eventRepository = eventRepository;
    }

    [HttpGet("clubs/{clubId}/events")]
    public IActionResult GetEventsByClub(Guid clubId)
    {
        var events = _eventRepository.GetByClubId(clubId);
        return Ok(events);
    }

    [HttpGet("events/{id}")]
    public IActionResult GetEvent(Guid id)
    {
        var ev = _eventRepository.GetById(id);
        if (ev == null) return NotFound();
        return Ok(ev);
    }

    [HttpPost("clubs/{clubId}/events")]
    public IActionResult CreateEvent(Guid clubId, [FromBody] CreateEventRequest request)
    {
        try
        {
            _eventService.CreateEvent(clubId, request.Title, request.Date, request.Capacity, request.Channel);
            return StatusCode(201); // Created
        }
        catch (ArgumentException ex)
        {
            return BadRequest(ex.Message);
        }
    }

    [HttpDelete("events/{id}")]
    public IActionResult DeleteEvent(Guid id)
    {
        var ev = _eventRepository.GetById(id);
        if (ev == null) return NotFound();

        _eventRepository.Delete(id);
        return NoContent();
    }
}


public class CreateEventRequest
{
    public string Title { get; set; } = string.Empty;
    public DateTime Date { get; set; }
    public int Capacity { get; set; }
    public string Channel { get; set; } = string.Empty;
}
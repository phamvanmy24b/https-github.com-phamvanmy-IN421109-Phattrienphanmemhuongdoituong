﻿using EduHub.Domain.Entities;
using EduHub.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EduHub.Infrastructure.Repositories;

public class InMemoryEventRepository : IEventRepository
{
    private readonly List<Event> _events = new();

    public void Add(Event ev) => _events.Add(ev);

    public Event GetById(Guid id) => _events.FirstOrDefault(e => e.Id == id);

    public IEnumerable<Event> GetByClubId(Guid clubId) => _events.Where(e => e.ClubId == clubId);

    public void Delete(Guid id)
    {
        var ev = GetById(id);
        if (ev != null) _events.Remove(ev);
    }
}
﻿using EduHub.Domain.Entities;
using System;
using Xunit;

namespace EduHub.Tests;

public class RegistrationTests
{
    [Fact]
    public void Create_WithValidData_ReturnsPendingStatus()
    {
        var r = Registration.Create(Guid.NewGuid(), Guid.NewGuid());
        Assert.Equal(RegistrationStatus.Pending, r.Status);
    }

    [Fact]
    public void Create_WithEmptyGuid_ThrowsArgumentException()
    {
        Assert.Throws<ArgumentException>(() => Registration.Create(Guid.Empty, Guid.NewGuid()));
    }

    [Fact]
    public void CancelThenConfirm_ThrowsInvalidOperationException_AndStatusRemainsCancelled()
    {
        var memberId = Guid.NewGuid();
        var eventId = Guid.NewGuid();
        var r = Registration.Create(memberId, eventId);

        r.Cancel(); // Đổi sang Cancelled

        // Bắt lỗi khi gọi Confirm
        var exception = Assert.Throws<InvalidOperationException>(() => r.Confirm());

        // Trạng thái vẫn phải là Cancelled
        Assert.Equal(RegistrationStatus.Cancelled, r.Status);
    }
}
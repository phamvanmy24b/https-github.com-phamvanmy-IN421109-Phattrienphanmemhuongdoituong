﻿using EduHub.Application.Interfaces;
using EduHub.Application.Services;
using EduHub.Domain.Entities;
using EduHub.Domain.Repositories;
using Moq;
using System;
using Xunit;

namespace EduHub.Tests;

public class EventServiceTests
{
    [Fact]
    public void CreateEvent_ValidInput_CallsAddAndSendOnce()
    {
        // Arrange
        var mockRepo = new Mock<IEventRepository>();
        var mockFactory = new Mock<INotificationFactory>();
        var mockNotifier = new Mock<INotificationService>();

        mockFactory.Setup(f => f.GetNotificationService("email")).Returns(mockNotifier.Object);

        var service = new EventService(mockRepo.Object, mockFactory.Object);

        // Act
        service.CreateEvent(Guid.NewGuid(), "DotNet Core Conf", DateTime.Now, 100, "email");

        // Assert
        mockRepo.Verify(r => r.Add(It.IsAny<Event>()), Times.Once);
        mockNotifier.Verify(n => n.Send(It.IsAny<string>()), Times.Once);
    }
}
﻿using EduHub.Application.Interfaces;
using EduHub.Domain.Entities;
using EduHub.Domain.Repositories;
using System;

namespace EduHub.Application.Services;

public class EventService
{
    private readonly IEventRepository _repository;
    private readonly INotificationFactory _notificationFactory;

    public EventService(IEventRepository repository, INotificationFactory notificationFactory)
    {
        _repository = repository;
        _notificationFactory = notificationFactory;
    }

    public void CreateEvent(Guid clubId, string title, DateTime date, int capacity, string channel)
    {
        var newEvent = Event.Create(clubId, title, date, capacity);

        _repository.Add(newEvent);

        var notifier = _notificationFactory.GetNotificationService(channel);
        notifier.Send($"Sự kiện mới: {title}");
    }
}
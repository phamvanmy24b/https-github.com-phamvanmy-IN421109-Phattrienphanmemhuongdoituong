﻿namespace EduHub.Application.Interfaces;

public interface INotificationFactory
{
    INotificationService GetNotificationService(string channel);
}
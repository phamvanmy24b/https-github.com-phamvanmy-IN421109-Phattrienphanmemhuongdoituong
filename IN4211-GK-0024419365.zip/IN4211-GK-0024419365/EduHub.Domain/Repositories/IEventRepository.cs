﻿using EduHub.Domain.Entities;
using System;
using System.Collections.Generic;

namespace EduHub.Domain.Repositories;

public interface IEventRepository
{
    void Add(Event ev);
    Event GetById(Guid id);
    IEnumerable<Event> GetByClubId(Guid clubId);
    void Delete(Guid id);
}